Lenias Safespace – Installationspaket

1. Lade den gesamten Ordnerinhalt (oder die ZIP-Datei entpackt) auf einen HTTPS-Webhost hoch.
   Einfacher Weg: https://app.netlify.com/drop
2. Die hochzuladende Ordnerstruktur muss index.html, manifest.webmanifest, sw.js,
   icon-192.png und icon-512.png gemeinsam im selben Ordner enthalten.
3. Öffne die veröffentlichte HTTPS-Adresse auf dem Handy deiner Freundin.
4. iPhone: In Safari auf „Teilen“ tippen → „Zum Home-Bildschirm“.
   Android: In Chrome auf ⋮ tippen → „App installieren“ oder „Zum Startbildschirm hinzufügen“.

Die Wasser- und Gute-Dinge-Einträge bleiben lokal im jeweiligen Browser/Handy gespeichert.
Sie werden nicht zwischen Geräten synchronisiert. Für Offline-Nutzung wird die App-Datei
nach dem ersten erfolgreichen Laden zwischengespeichert; externe Google Fonts benötigen ggf. Internet.
